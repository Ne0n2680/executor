﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;

namespace PoisionIITest
{
    public partial class Form1 : Form
    {
        ExploitAPI module = new ExploitAPI();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox4.Text = " ";
        }

        private void Execute_Click(object sender, EventArgs e)
        {
            module.SendLuaScript(textBox4.Text);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            textBox4.Text = "Please attach the executor.";

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            ScriptHubs openform = new ScriptHubs();
            openform.Hide();
            label3.Text = "Executor status : Online";
            label3.ForeColor = Color.Lime;
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            module.LaunchExploit();
            timer1.Stop();
            textBox4.Text = "";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
      
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ScriptHubs openform = new ScriptHubs();
            openform.Show();
        }
    }
}
