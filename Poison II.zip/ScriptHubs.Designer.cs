﻿
namespace PoisionIITest
{
    partial class ScriptHubs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this;
            this.bunifuDragControl1.Vertical = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(309, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(27, 26);
            this.button1.TabIndex = 0;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 80);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(57, 26);
            this.button2.TabIndex = 1;
            this.button2.Text = "Physco";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(75, 80);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(57, 26);
            this.button3.TabIndex = 2;
            this.button3.Text = "Chara";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(138, 80);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(57, 26);
            this.button4.TabIndex = 3;
            this.button4.Text = "Sword";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(201, 80);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(57, 26);
            this.button5.TabIndex = 4;
            this.button5.Text = "Ak47";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label4.Location = new System.Drawing.Point(-246, 30);
            this.label4.MaximumSize = new System.Drawing.Size(107, 188);
            this.label4.MinimumSize = new System.Drawing.Size(800, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(800, 13);
            this.label4.TabIndex = 11;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Poison II";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "+ script hub";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(268, 80);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(57, 26);
            this.button6.TabIndex = 21;
            this.button6.Text = "AKV";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(12, 112);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(57, 26);
            this.button7.TabIndex = 22;
            this.button7.Text = "Killbot";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(75, 112);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(57, 26);
            this.button8.TabIndex = 23;
            this.button8.Text = "Element";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(138, 112);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(57, 26);
            this.button9.TabIndex = 24;
            this.button9.Text = "Suicide";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(201, 112);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(57, 26);
            this.button10.TabIndex = 25;
            this.button10.Text = "Creeper";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(268, 112);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(57, 26);
            this.button11.TabIndex = 26;
            this.button11.Text = "Pacifist";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(12, 144);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(57, 26);
            this.button12.TabIndex = 27;
            this.button12.Text = "Angle";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(75, 144);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(57, 26);
            this.button13.TabIndex = 28;
            this.button13.Text = "Warden";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(138, 144);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(57, 26);
            this.button14.TabIndex = 29;
            this.button14.Text = "Distored";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(201, 144);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(57, 26);
            this.button15.TabIndex = 30;
            this.button15.Text = "Flame";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(268, 144);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(57, 26);
            this.button16.TabIndex = 31;
            this.button16.Text = "John";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(12, 176);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(57, 26);
            this.button17.TabIndex = 32;
            this.button17.Text = "Daddy";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(75, 176);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(57, 26);
            this.button18.TabIndex = 33;
            this.button18.Text = "Switcher";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(138, 176);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(57, 26);
            this.button19.TabIndex = 34;
            this.button19.Text = "Mask";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(201, 176);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(57, 26);
            this.button20.TabIndex = 35;
            this.button20.Text = "God";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(268, 176);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(57, 26);
            this.button21.TabIndex = 36;
            this.button21.Text = "Knife";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(12, 208);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(57, 26);
            this.button22.TabIndex = 37;
            this.button22.Text = "Claws";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(75, 208);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(57, 26);
            this.button23.TabIndex = 38;
            this.button23.Text = "SCP-106";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(138, 208);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(57, 26);
            this.button24.TabIndex = 39;
            this.button24.Text = "Pharoh";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(201, 208);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(57, 26);
            this.button25.TabIndex = 40;
            this.button25.Text = "Drone";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(268, 208);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(57, 26);
            this.button26.TabIndex = 41;
            this.button26.Text = "Sun";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(12, 240);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(57, 26);
            this.button27.TabIndex = 42;
            this.button27.Text = "Echo";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(75, 240);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(57, 26);
            this.button28.TabIndex = 43;
            this.button28.Text = "Incensio";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(138, 240);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(57, 26);
            this.button29.TabIndex = 44;
            this.button29.Text = "Light C";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(201, 240);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(57, 26);
            this.button30.TabIndex = 45;
            this.button30.Text = "Grappler";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(268, 240);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(57, 26);
            this.button31.TabIndex = 46;
            this.button31.Text = "Gauntlet";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(12, 272);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(57, 26);
            this.button32.TabIndex = 48;
            this.button32.Text = "Assasian";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(75, 272);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(57, 26);
            this.button33.TabIndex = 49;
            this.button33.Text = "Lost";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(138, 272);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(57, 26);
            this.button34.TabIndex = 50;
            this.button34.Text = "Cop";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(201, 272);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(57, 26);
            this.button35.TabIndex = 51;
            this.button35.Text = "Despira";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 54);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(313, 20);
            this.textBox1.TabIndex = 52;
            this.textBox1.Text = "Me";
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(268, 272);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(57, 26);
            this.button36.TabIndex = 53;
            this.button36.Text = "Blades";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(12, 304);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(57, 26);
            this.button37.TabIndex = 54;
            this.button37.Text = "Magic";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(75, 304);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(57, 26);
            this.button38.TabIndex = 55;
            this.button38.Text = "Glitcher";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(138, 304);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(57, 26);
            this.button39.TabIndex = 56;
            this.button39.Text = "Bizzaro";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(201, 304);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(57, 26);
            this.button40.TabIndex = 57;
            this.button40.Text = "Eye";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(268, 304);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(57, 26);
            this.button41.TabIndex = 58;
            this.button41.Text = "Zen";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(12, 336);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(57, 26);
            this.button42.TabIndex = 59;
            this.button42.Text = "Reaper";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(75, 336);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(57, 26);
            this.button43.TabIndex = 60;
            this.button43.Text = "Caducus";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(138, 336);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(57, 26);
            this.button44.TabIndex = 61;
            this.button44.Text = "Vadar";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(201, 336);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(57, 26);
            this.button45.TabIndex = 62;
            this.button45.Text = "Lutruis";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(268, 336);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(57, 26);
            this.button46.TabIndex = 63;
            this.button46.Text = "M14";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(12, 368);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(57, 26);
            this.button47.TabIndex = 64;
            this.button47.Text = "Dragon";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(75, 368);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(57, 26);
            this.button48.TabIndex = 65;
            this.button48.Text = "Doom";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(138, 368);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(57, 26);
            this.button49.TabIndex = 66;
            this.button49.Text = "Glove";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(201, 368);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(57, 26);
            this.button50.TabIndex = 67;
            this.button50.Text = "Sans";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(268, 368);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(57, 26);
            this.button51.TabIndex = 68;
            this.button51.Text = "God 2";
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // ScriptHubs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(337, 406);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ScriptHubs";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Script hub";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.ScriptHubs_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
    }
}