﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;

namespace PoisionIITest
{
    public partial class ScriptHubs : Form
    {
        ExploitAPI module = new ExploitAPI();
        public ScriptHubs()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Killer.lua");
            module.SendLuaScript(Script);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://pastebin.com/raw/18JTx6kF");
            module.SendLuaScript(Script);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Ne0n2680/AdminPanel/main/ramd");
            module.SendLuaScript(Script);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Chara.lua");
            module.SendLuaScript(Script);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Demonic%20Sword.lua");
            module.SendLuaScript(Script);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/M41451.lua");
            module.SendLuaScript(Script);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/AKV.lua");
            module.SendLuaScript(Script);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/KillbotV2.lua");
            module.SendLuaScript(Script);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Master%20Of%20Elements.lua");
            module.SendLuaScript(Script);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://pastebin.com/raw/aX9aJbt1");
            module.SendLuaScript(Script);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/The%20Angel.lua");
            module.SendLuaScript(Script);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/The%20Warden.lua");
            module.SendLuaScript(Script);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/The%20Distorted.lua");
            module.SendLuaScript(Script);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Flamethrower.lua");
            module.SendLuaScript(Script);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/John%20Doe.lua");
            module.SendLuaScript(Script);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Big%20Daddy.lua");
            module.SendLuaScript(Script);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Free%20Star%20Glitcher.lua");
            module.SendLuaScript(Script);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Mask.lua");
            module.SendLuaScript(Script);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Omni%20God.lua");
            module.SendLuaScript(Script);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Grab%20Knife%20V3%20FE%20test.lua");
            module.SendLuaScript(Script);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Golden%20Claws.lua");
            module.SendLuaScript(Script);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/SCP-106.lua");
            module.SendLuaScript(Script);
        }

        private void ScriptHubs_Load(object sender, EventArgs e)
        {

        }

        private void button24_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Pharoh.lua");
            module.SendLuaScript(Script);
        }

        private void button25_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Drone.lua");
            module.SendLuaScript(Script);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/The%20Sun%20Is%20A%20Deadly%20Laser.lua");
            module.SendLuaScript(Script);
        }

        private void button27_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Echo%20Banisher.lua");
            module.SendLuaScript(Script);
        }

        private void button28_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Incension%20Reborn.lua");
            module.SendLuaScript(Script);
        }

        private void button29_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/LightningSword.lua");
            module.SendLuaScript(Script);
        }

        private void button30_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Grappler.lua");
            module.SendLuaScript(Script);
        }

        private void button31_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Tornado%20Gauntlet.lua");
            module.SendLuaScript(Script);
        }

        private void button32_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/The%20Assasian.lua");
            module.SendLuaScript(Script);
        }

        private void button33_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Lost%20Hope.lua");
            module.SendLuaScript(Script);
        }

        private void button34_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Cop.lua");
            module.SendLuaScript(Script);
        }

        private void button35_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Despira.lua");
            module.SendLuaScript(Script);
        }

        private void button36_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Hidden%20Blades.lua");
            module.SendLuaScript(Script);
        }

        private void button37_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Magic.lua");
            module.SendLuaScript(Script);
        }

        private void button38_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Nebula%20Star%20Glitcher.lua");
            module.SendLuaScript(Script);
        }

        private void button39_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Bizzaro.lua");
            module.SendLuaScript(Script);
        }

        private void button40_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Eyo%20Zen.lua");
            module.SendLuaScript(Script);
        }

        private void button41_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/FEZen.lua");
            module.SendLuaScript(Script);
        }

        private void button42_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Reaper.lua");
            module.SendLuaScript(Script);
        }

        private void button43_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/cadacus.lua");
            module.SendLuaScript(Script);
        }

        private void button44_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Darth%20Vadar.lua");
            module.SendLuaScript(Script);
        }

        private void button45_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Lustris%20V2.lua");
            module.SendLuaScript(Script);
        }

        private void button46_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/M41451.lua");
            module.SendLuaScript(Script);
        }

        private void button47_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Dragonian%20Pyramus.lua");
            module.SendLuaScript(Script);
        }

        private void button48_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/DoomspireBrickbattler.lua");
            module.SendLuaScript(Script);
        }

        private void button49_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Glove%20and%20sword.lua");
            module.SendLuaScript(Script);
        }

        private void button50_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Evolution-Hub/main/Nightmare%20Sans.lua");
            module.SendLuaScript(Script);
        }

        private void button51_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/God%20Eater.lua");
            module.SendLuaScript(Script);
        }
    }
}
